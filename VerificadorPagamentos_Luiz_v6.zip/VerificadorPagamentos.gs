/**
 * VERIFICADOR DE PAGAMENTOS — Planilha Luiz
 *
 * Este arquivo é independente dos demais códigos da sua planilha.
 * Pode ficar em um projeto Apps Script separado para não tocar no seu código atual.
 *
 * 1) Coloque o ID da Planilha Luiz em SPREADSHEET_ID.
 * 2) Crie um token forte e coloque em TOKEN.
 * 3) Implante como Aplicativo da Web executando como você.
 * 4) A extensão usa a URL /exec e o mesmo TOKEN.
 */

const CONFIG = {
  SPREADSHEET_ID: '1JTp2h9ZQ-WtXW71T4rxkZTbOBd0blGSv7q3Pyr8rWirJexDoatOenlWp',
  TOKEN: '59513c62d23cc730c1eef6cb76f79e5c3848baae084c381cea6f312260db3fa6',
  TIMEZONE: 'America/Sao_Paulo'
};

const MONTHS = [
  'JANEIRO','FEVEREIRO','MARÇO','ABRIL','MAIO','JUNHO',
  'JULHO','AGOSTO','SETEMBRO','OUTUBRO','NOVEMBRO','DEZEMBRO'
];

function doGet(e) {
  try {
    if (!e || !e.parameter || e.parameter.token !== CONFIG.TOKEN) {
      return json_({ ok: false, error: 'TOKEN_INVALIDO' });
    }

    const action = String(e.parameter.action || 'ping').toLowerCase();

    if (action === 'ping') {
      const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
      return json_({
        ok: true,
        message: 'Verificador conectado.',
        spreadsheet: ss.getName(),
        sheet: e.parameter.sheet || getCurrentMonthSheetName_()
      });
    }

    if (action === 'pending') {
      const sheetName = e.parameter.sheet || getCurrentMonthSheetName_();
      return json_({ ok: true, ...getPending_(sheetName) });
    }

    if (action === 'update') {
      const sheetName = String(e.parameter.sheet || getCurrentMonthSheetName_());
      const row = Number(e.parameter.row || 0);
      const contract = normalizeDigits_(e.parameter.contract || '');
      const desiredStatus = String(e.parameter.status || '').trim().toUpperCase();

      if (!row || !contract || desiredStatus !== 'VERIFICAR') {
        return json_({ ok: false, error: 'PARAMETROS_INVALIDOS' });
      }

      return json_({ ok: true, ...updateStatus_(sheetName, row, contract, desiredStatus) });
    }

    return json_({ ok: false, error: 'ACAO_DESCONHECIDA' });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message ? err.message : err) });
  }
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function getCurrentMonthSheetName_() {
  const now = new Date();
  const month = Number(Utilities.formatDate(now, CONFIG.TIMEZONE, 'M')) - 1;
  const year = Utilities.formatDate(now, CONFIG.TIMEZONE, 'yy');
  return `${MONTHS[month]} ${year}`;
}

function normalize_(value) {
  return String(value == null ? '' : value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeDigits_(value) {
  return String(value == null ? '' : value).replace(/\D/g, '');
}

function findHeader_(values) {
  const limit = Math.min(values.length, 20);
  for (let r = 0; r < limit; r++) {
    const row = values[r].map(normalize_);
    const contractCol = row.findIndex(v => v === 'contrato' || v === 'conta' || v.includes('contrato'));
    const nameCol = row.findIndex(v => v === 'nome' || v.includes('nome'));
    const dueCol = row.findIndex(v => v === 'vencimento' || v.includes('vencimento'));
    const valueCol = row.findIndex(v => v === 'valor' || v.includes('valor'));
    const statusCol = row.findIndex(v => v === 'status' || v.includes('status'));

    if (contractCol >= 0 && statusCol >= 0 && nameCol >= 0) {
      return { rowIndex0: r, contractCol, nameCol, dueCol, valueCol, statusCol };
    }
  }
  throw new Error('Cabeçalho CONTRATO/STATUS não encontrado nos primeiros 20 registros da aba.');
}

function getPending_(sheetName) {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) throw new Error(`Aba "${sheetName}" não encontrada.`);

  const range = sheet.getDataRange();
  const values = range.getDisplayValues();
  if (!values.length) return { sheet: sheetName, items: [] };

  const header = findHeader_(values);
  const items = [];

  for (let r = header.rowIndex0 + 1; r < values.length; r++) {
    const row = values[r];
    const status = normalize_(row[header.statusCol]);
    if (status !== 'pendente') continue;

    const contract = normalizeDigits_(row[header.contractCol]);
    if (!contract) continue;

    items.push({
      rowNumber: r + 1,
      contract,
      name: row[header.nameCol] || '',
      dueDate: header.dueCol >= 0 ? row[header.dueCol] || '' : '',
      value: header.valueCol >= 0 ? row[header.valueCol] || '' : '',
      status: 'PENDENTE',
      sheet: sheetName,
      selected: true
    });
  }

  return { sheet: sheetName, items };
}

function updateStatus_(sheetName, rowNumber, contract, desiredStatus) {
  const ss = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) throw new Error(`Aba "${sheetName}" não encontrada.`);
  if (rowNumber < 1 || rowNumber > sheet.getMaxRows()) throw new Error('Linha inválida.');

  const values = sheet.getRange(rowNumber, 1, 1, Math.max(7, sheet.getLastColumn())).getDisplayValues()[0];
  const headerValues = sheet.getRange(1, 1, Math.min(20, sheet.getLastRow()), Math.max(7, sheet.getLastColumn())).getDisplayValues();
  const header = findHeader_(headerValues);

  const currentContract = normalizeDigits_(values[header.contractCol]);
  const currentStatus = normalize_(values[header.statusCol]);

  if (currentContract !== contract) {
    return {
      updated: false,
      skipped: true,
      reason: 'CONTRATO_NA_LINHA_NAO_CONFERE',
      currentContract
    };
  }

  if (currentStatus !== 'pendente') {
    return {
      updated: false,
      skipped: true,
      reason: 'STATUS_JA_MUDOU',
      currentStatus
    };
  }

  sheet.getRange(rowNumber, header.statusCol + 1).setValue(desiredStatus);
  SpreadsheetApp.flush();

  return {
    updated: true,
    skipped: false,
    rowNumber,
    contract,
    status: desiredStatus
  };
}
