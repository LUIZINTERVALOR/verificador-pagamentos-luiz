/**
 * PLANILHA LUIZ — VERIFICADOR DE PAGAMENTOS
 * Arquivo separado dentro do MESMO projeto Apps Script da Planilha Luiz.
 * Não cria outro CONFIG e não cria outro onOpen().
 */

var VP_TOKEN_ = '59513c62d23cc730c1eef6cb76f79e5c3848baae084c381cea6f312260db3fa6';

function VP_abrirPainel() {
  var html = HtmlService.createHtmlOutput(VP_htmlPainel_())
    .setWidth(980)
    .setHeight(720);

  SpreadsheetApp.getUi().showModalDialog(html, '🔎 Verificador de Pagamentos');
}

function VP_nomeAbaMesAtual_() {
  var tz = Session.getScriptTimeZone() || 'America/Sao_Paulo';
  var agora = new Date();
  var meses = ['JANEIRO','FEVEREIRO','MARÇO','ABRIL','MAIO','JUNHO','JULHO','AGOSTO','SETEMBRO','OUTUBRO','NOVEMBRO','DEZEMBRO'];
  var mes = Number(Utilities.formatDate(agora, tz, 'M')) - 1;
  var ano = Utilities.formatDate(agora, tz, 'yy');
  return meses[mes] + ' ' + ano;
}

function VP_normalize_(value) {
  return String(value == null ? '' : value)
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().replace(/\s+/g, ' ').trim();
}

function VP_digits_(value) {
  return String(value == null ? '' : value).replace(/\D/g, '');
}

function VP_header_(values) {
  for (var r = 0; r < Math.min(values.length, 20); r++) {
    var row = values[r].map(VP_normalize_);
    var contractCol = row.findIndex(function(v) { return v === 'contrato' || v === 'conta' || v.indexOf('contrato') >= 0; });
    var nameCol = row.findIndex(function(v) { return v === 'nome' || v.indexOf('nome') >= 0; });
    var dueCol = row.findIndex(function(v) { return v === 'vencimento' || v.indexOf('vencimento') >= 0; });
    var valueCol = row.findIndex(function(v) { return v === 'valor' || v.indexOf('valor') >= 0; });
    var statusCol = row.findIndex(function(v) { return v === 'status' || v.indexOf('status') >= 0; });
    if (contractCol >= 0 && nameCol >= 0 && statusCol >= 0) {
      return { rowIndex0: r, contractCol: contractCol, nameCol: nameCol, dueCol: dueCol, valueCol: valueCol, statusCol: statusCol };
    }
  }
  throw new Error('Não encontrei CONTRATO, NOME e STATUS no cabeçalho da aba.');
}

function VP_listarAbasMes_() {
  var regex = /^(JANEIRO|FEVEREIRO|MARÇO|ABRIL|MAIO|JUNHO|JULHO|AGOSTO|SETEMBRO|OUTUBRO|NOVEMBRO|DEZEMBRO)\s+\d{2}$/i;
  return SpreadsheetApp.getActiveSpreadsheet().getSheets()
    .map(function(s) { return s.getName(); })
    .filter(function(n) { return regex.test(String(n).trim()); })
    .sort(function(a,b) { return a.localeCompare(b, 'pt-BR'); });
}

function VP_resolverAba_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var alvo = String(name || '').trim();
  var exact = ss.getSheetByName(alvo);
  if (exact) return exact;
  var norm = VP_normalize_(alvo);
  var found = ss.getSheets().find(function(s) { return VP_normalize_(s.getName()) === norm; });
  if (!found) throw new Error('Aba não encontrada: ' + alvo);
  return found;
}

function VP_getPendentes(nomeAba) {
  var sheet = VP_resolverAba_(nomeAba || VP_nomeAbaMesAtual_());
  var values = sheet.getDataRange().getDisplayValues();
  if (!values.length) return { ok: true, sheet: sheet.getName(), total: 0, items: [] };
  var h = VP_header_(values);
  var items = [];

  for (var r = h.rowIndex0 + 1; r < values.length; r++) {
    var row = values[r];
    if (VP_normalize_(row[h.statusCol]) !== 'pendente') continue;
    var contract = VP_digits_(row[h.contractCol]);
    if (!contract) continue;
    items.push({
      rowNumber: r + 1,
      contract: contract,
      name: row[h.nameCol] || '',
      dueDate: h.dueCol >= 0 ? (row[h.dueCol] || '') : '',
      value: h.valueCol >= 0 ? (row[h.valueCol] || '') : '',
      status: 'PENDENTE',
      sheet: sheet.getName()
    });
  }

  return { ok: true, sheet: sheet.getName(), total: items.length, items: items };
}

function VP_atualizarStatus_(params) {
  if (!params) throw new Error('Parâmetros não informados.');
  var sheet = VP_resolverAba_(params.sheet);
  var rowNumber = Number(params.row);
  var expectedContract = VP_digits_(params.contract);
  var newStatus = String(params.status || '').trim().toUpperCase();
  if (!rowNumber || !expectedContract || newStatus !== 'VERIFICAR') {
    throw new Error('Dados inválidos para atualização.');
  }

  var values = sheet.getDataRange().getDisplayValues();
  var h = VP_header_(values);
  if (rowNumber < h.rowIndex0 + 2 || rowNumber > values.length) {
    throw new Error('Linha inválida: ' + rowNumber);
  }

  var actualContract = VP_digits_(values[rowNumber - 1][h.contractCol]);
  if (actualContract !== expectedContract) {
    throw new Error('CONTA DIVERGENTE. Esperada ' + expectedContract + ', encontrada ' + (actualContract || 'vazia') + '.');
  }

  sheet.getRange(rowNumber, h.statusCol + 1).setValue('VERIFICAR');
  return { ok: true, sheet: sheet.getName(), row: rowNumber, contract: expectedContract, status: 'VERIFICAR' };
}

function VP_api_(e) {
  var p = e && e.parameter ? e.parameter : {};
  var token = String(p.token || '');
  if (token !== VP_TOKEN_) throw new Error('TOKEN_INVALIDO');

  var action = String(p.action || 'ping').toLowerCase();
  if (action === 'ping') return { ok: true, service: 'VP_LUIZ', time: new Date().toISOString() };
  if (action === 'pending') return VP_getPendentes(p.sheet || VP_nomeAbaMesAtual_());
  if (action === 'update') return VP_atualizarStatus_(p);
  throw new Error('Ação não reconhecida: ' + action);
}

/** Web App do mesmo projeto da Planilha Luiz. */
function doGet(e) {
  try {
    return ContentService
      .createTextOutput(JSON.stringify(VP_api_(e)))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: err.message || String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function VP_htmlPainel_() {
  var meses = VP_listarAbasMes_();
  var atual = VP_nomeAbaMesAtual_();
  if (meses.indexOf(atual) < 0) meses.unshift(atual);
  var options = meses.map(function(m) {
    return '<option value="' + VP_escapeHtml_(m) + '">' + VP_escapeHtml_(m) + '</option>';
  }).join('');

  return '<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><style>' +
    '*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:linear-gradient(135deg,#eaf3ff,#f8fbff);color:#12304a}.wrap{padding:20px}.head{background:linear-gradient(135deg,#0757a8,#1476d4);color:#fff;border-radius:18px;padding:18px 20px;box-shadow:0 10px 30px rgba(20,75,130,.18)}.head h1{margin:0;font-size:22px}.head p{margin:6px 0 0;font-size:12px;opacity:.92}.toolbar{display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin:16px 0}.field{display:flex;flex-direction:column;gap:6px;min-width:210px}.field label{font-size:11px;font-weight:800;text-transform:uppercase;color:#4d6880}select{height:40px;border:1px solid #c8d9e8;border-radius:10px;padding:0 12px;font-weight:700;background:#fff}button{height:40px;border:0;border-radius:10px;padding:0 16px;font-weight:800;cursor:pointer}.primary{background:#0757a8;color:#fff}.green{background:#16a34a;color:#fff}.gray{background:#eef3f7;color:#23445e}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px}.card{background:#fff;border-radius:14px;padding:14px;border:1px solid #d8e6f1;box-shadow:0 6px 18px rgba(16,68,110,.06)}.k{font-size:10px;font-weight:800;text-transform:uppercase;color:#66819a}.v{font-size:23px;font-weight:900;margin-top:4px}.panel{background:#fff;border:1px solid #d8e6f1;border-radius:14px;overflow:hidden}.panel-title{padding:12px 14px;font-size:13px;font-weight:900;border-bottom:1px solid #e6eef5;display:flex;justify-content:space-between}.list{max-height:405px;overflow:auto}.row{display:grid;grid-template-columns:44px 145px minmax(170px,1fr) 100px 95px;gap:8px;align-items:center;padding:10px 12px;border-bottom:1px solid #edf3f8;font-size:11px}.row:nth-child(even){background:#f5faff}.num{font-weight:900}.name{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.money{font-weight:800}.empty{padding:28px;text-align:center;color:#70889c}.bottom{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-top:14px}.status{font-size:11px;font-weight:800;color:#577086}' +
    '</style></head><body><div class="wrap"><div class="head"><h1>🔎 Verificador de Pagamentos</h1><p>Fila de contratos com STATUS = PENDENTE da sua Planilha Luiz.</p></div><div class="toolbar"><div class="field"><label>Mês</label><select id="mes">' + options + '</select></div><button class="primary" onclick="carregar()">🔄 Atualizar pendentes</button><button class="green" onclick="preparar()">📤 Enviar para extensão</button><button class="gray" onclick="google.script.host.close()">Fechar</button></div><div class="cards"><div class="card"><div class="k">Pendentes</div><div class="v" id="cPend">0</div></div><div class="card"><div class="k">Aba</div><div class="v" id="cMes" style="font-size:15px">—</div></div><div class="card"><div class="k">Fila preparada</div><div class="v" id="cFila" style="font-size:15px">NÃO</div></div><div class="card"><div class="k">Modo</div><div class="v" style="font-size:15px">CLIPBOARD</div></div></div><div class="panel"><div class="panel-title"><span>Contratos encontrados</span><span id="info">Carregando...</span></div><div id="list" class="list"><div class="empty">Carregando...</div></div></div><div class="bottom"><div id="status" class="status">Aguardando.</div><div style="font-size:10px;color:#7b91a4">A fila é enviada copiando os dados para a área de transferência.</div></div></div><script>' +
    'function esc(s){return String(s==null?"":s).replace(/[&<>"\']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","\'":"&#39;"}[c]})}function render(r){document.getElementById("cPend").textContent=(r.items||[]).length;document.getElementById("cMes").textContent=r.sheet||"—";document.getElementById("info").textContent=(r.items||[]).length+" contrato(s)";var l=document.getElementById("list");if(!r.items||!r.items.length){l.innerHTML="<div class=empty>Nenhum PENDENTE encontrado nesta aba.</div>";return}l.innerHTML=r.items.map(function(x,i){return "<div class=row><div class=num>"+(i+1)+"</div><div><strong>"+esc(x.contract)+"</strong></div><div class=name title=\""+esc(x.name)+"\">"+esc(x.name||"Cliente sem nome")+"</div><div>"+esc(x.dueDate||"—")+"</div><div class=money>"+esc(x.value||"—")+"</div></div>"}).join("")}function carregar(){document.getElementById("status").textContent="Buscando os PENDENTES...";google.script.run.withSuccessHandler(function(r){render(r);document.getElementById("status").textContent="Fila atualizada."}).withFailureHandler(function(e){document.getElementById("status").textContent="Erro: "+(e.message||e)}).VP_getPendentes(document.getElementById("mes").value)}function preparar(){document.getElementById("status").textContent="Preparando e copiando a fila...";google.script.run.withSuccessHandler(function(p){var txt=JSON.stringify(p);navigator.clipboard.writeText(txt).then(function(){document.getElementById("cFila").textContent="SIM";document.getElementById("status").textContent="Fila copiada. Abra a extensão e clique em IMPORTAR DA PLANILHA."}).catch(function(){prompt("Copie esta fila manualmente e use IMPORTAR DA PLANILHA:",txt)})}).withFailureHandler(function(e){document.getElementById("status").textContent="Erro: "+(e.message||e)}).VP_prepararFila(document.getElementById("mes").value)}function init(){carregar()}init();</script></body></html>';
}

function VP_prepararFila(nomeAba) {
  var result = VP_getPendentes(nomeAba || VP_nomeAbaMesAtual_());
  var payload = { version: 'VP_LUIZ_1', createdAt: new Date().toISOString(), sheet: result.sheet, total: result.items.length, items: result.items };
  PropertiesService.getUserProperties().setProperty('VP_FILA_PAGAMENTOS', JSON.stringify(payload));
  return payload;
}

function VP_escapeHtml_(value) {
  return String(value == null ? '' : value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
