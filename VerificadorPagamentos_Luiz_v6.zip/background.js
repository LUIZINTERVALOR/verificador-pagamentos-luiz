const BOLETO_BASE = 'http://totem/Totem/ExibeBoleto?idFinalidade=PAR&usuario=&ban=';
const DEFAULT_CONFIG = {
  apiUrl: '',
  token: '59513c62d23cc730c1eef6cb76f79e5c3848baae084c381cea6f312260db3fa6',
  autoEnabled: false
};
const HISTORY_LIMIT = 500;
const TIMEOUT_MS = 20000;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function getConfig() {
  const data = await chrome.storage.local.get('verificadorConfig');
  return { ...DEFAULT_CONFIG, ...(data.verificadorConfig || {}) };
}

async function setConfig(next) {
  const current = await getConfig();
  const merged = { ...current, ...next };
  await chrome.storage.local.set({ verificadorConfig: merged });
  return merged;
}

async function getRunState() {
  const data = await chrome.storage.local.get('verificadorRun');
  return data.verificadorRun || {
    running: false,
    queue: [],
    index: 0,
    verified: 0,
    pending: 0,
    changed: 0,
    errors: 0,
    startedAt: null,
    current: null,
    lastResult: null,
    workerTabId: null,
    waitingContract: null
  };
}

async function setRunState(state) {
  await chrome.storage.local.set({ verificadorRun: state });
}

async function getHistory() {
  const data = await chrome.storage.local.get('verificadorHistory');
  return Array.isArray(data.verificadorHistory) ? data.verificadorHistory : [];
}

async function addHistory(entry) {
  const history = await getHistory();
  history.unshift(entry);
  if (history.length > HISTORY_LIMIT) history.length = HISTORY_LIMIT;
  await chrome.storage.local.set({ verificadorHistory: history });
}

function safeApiUrl(apiUrl) {
  if (!apiUrl) throw new Error('URL do Web App não configurada.');
  const u = new URL(apiUrl);
  if (!/^https:$/.test(u.protocol)) throw new Error('A URL do Web App precisa ser HTTPS.');
  return u;
}

async function apiGet(params) {
  const config = await getConfig();
  const u = safeApiUrl(config.apiUrl);
  Object.entries(params).forEach(([k, v]) => u.searchParams.set(k, String(v ?? '')));
  u.searchParams.set('token', config.token || '');

  const response = await fetch(u.toString(), {
    method: 'GET',
    redirect: 'follow',
    cache: 'no-store'
  });
  if (!response.ok) throw new Error(`Web App HTTP ${response.status}`);
  const text = await response.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error('O Web App respondeu algo que não é JSON.');
  }
  if (!json.ok) throw new Error(json.error || 'Erro retornado pelo Web App.');
  return json;
}

function escapeRegExp(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function buildBoletoUrl(contract) {
  return BOLETO_BASE + encodeURIComponent(String(contract).trim());
}

async function closeWorker(state) {
  if (state.workerTabId != null) {
    try {
      await chrome.tabs.remove(state.workerTabId);
    } catch (_) {}
  }
  state.workerTabId = null;
}

async function stopRun(reason = 'Interrompido pelo usuário.') {
  const state = await getRunState();
  state.running = false;
  state.waitingContract = null;
  state.current = null;
  state.lastResult = {
    type: 'info',
    message: reason,
    at: new Date().toISOString()
  };
  await closeWorker(state);
  await setRunState(state);
}

async function finishRun() {
  const state = await getRunState();
  state.running = false;
  state.waitingContract = null;
  state.current = null;
  state.lastResult = {
    type: 'done',
    message: 'Fila concluída.',
    at: new Date().toISOString()
  };
  await closeWorker(state);
  await setRunState(state);
}

async function startRun(queue) {
  if (!Array.isArray(queue) || queue.length === 0) {
    throw new Error('Nenhum contrato pendente foi selecionado.');
  }

  await stopRun('Nova verificação iniciada.');
  const state = {
    running: true,
    queue,
    index: 0,
    verified: 0,
    pending: 0,
    changed: 0,
    errors: 0,
    startedAt: new Date().toISOString(),
    current: queue[0],
    lastResult: null,
    workerTabId: null,
    waitingContract: null
  };
  await setRunState(state);
  await processNext();
}

async function processNext() {
  const state = await getRunState();
  if (!state.running) return;
  if (state.index >= state.queue.length) {
    await finishRun();
    return;
  }

  const item = state.queue[state.index];
  state.current = item;
  state.waitingContract = String(item.contract);
  await setRunState(state);

  if (state.workerTabId == null) {
    const tab = await chrome.tabs.create({
      url: buildBoletoUrl(item.contract),
      active: false
    });
    state.workerTabId = tab.id;
    await setRunState(state);
  } else {
    await chrome.tabs.update(state.workerTabId, {
      url: buildBoletoUrl(item.contract),
      active: false
    });
  }

  chrome.alarms.create('verificador_timeout', { delayInMinutes: TIMEOUT_MS / 60000 });
}

async function handleResult(result) {
  const state = await getRunState();
  if (!state.running || !state.current) return;

  const expected = String(state.current.contract);
  if (String(result.contract || '') !== expected) {
    return await recordOutcome({
      type: 'error',
      code: 'CONTA_DIVERGENTE',
      message: `A página retornou a conta ${result.contract || 'não identificada'}, mas era esperada ${expected}.`
    });
  }

  let sheetUpdate = null;
  if (result.status === 'VERIFICAR') {
    const config = await getConfig();
    if (config.apiUrl) {
      try {
        sheetUpdate = await apiGet({
          action: 'update',
          sheet: state.current.sheet,
          row: state.current.rowNumber,
          contract: expected,
          status: 'VERIFICAR'
        });
      } catch (err) {
        return await recordOutcome({
          type: 'error',
          code: 'ERRO_AO_ATUALIZAR_PLANILHA',
          message: err.message
        });
      }
    } else {
      sheetUpdate = {
        ok: false,
        skipped: true,
        reason: 'URL do Web App ainda não configurada.'
      };
    }
  }

  await recordOutcome({
    type: result.status === 'VERIFICAR' ? 'changed' : (result.status === 'PENDENTE' ? 'pending' : 'error'),
    code: result.code,
    message: result.message,
    excerpt: result.excerpt,
    pageUrl: result.pageUrl,
    sheetUpdate
  });
}

async function recordOutcome(outcome) {
  const state = await getRunState();
  if (!state.running || !state.current) return;

  const item = state.current;
  const finalType = outcome.type;
  state.verified += 1;
  if (finalType === 'pending') state.pending += 1;
  if (finalType === 'changed') state.changed += 1;
  if (finalType === 'error') state.errors += 1;

  const entry = {
    at: new Date().toISOString(),
    contract: String(item.contract),
    name: item.name || '',
    value: item.value || '',
    dueDate: item.dueDate || '',
    sheet: item.sheet || '',
    rowNumber: item.rowNumber || null,
    outcome: finalType,
    code: outcome.code || '',
    message: outcome.message || '',
    excerpt: outcome.excerpt || '',
    pageUrl: outcome.pageUrl || '',
    sheetUpdate: outcome.sheetUpdate || null
  };
  await addHistory(entry);

  state.lastResult = entry;
  state.index += 1;
  state.waitingContract = null;
  state.current = null;
  await setRunState(state);
  chrome.alarms.clear('verificador_timeout').catch(() => {});
  await sleep(250);
  await processNext();
}

async function refreshPending(sheet) {
  return apiGet({ action: 'pending', sheet });
}

async function getAutoStatus() {
  const config = await getConfig();
  const alarms = await chrome.alarms.getAll();
  const auto = alarms
    .filter(a => a.name && a.name.startsWith('verificador_auto_'))
    .sort((a,b) => (a.scheduledTime || Infinity) - (b.scheduledTime || Infinity));
  let next = null;
  if (auto.length) {
    const a = auto[0];
    const suffix = a.name.replace('verificador_auto_', '');
    const hh = suffix.slice(0,2);
    const mm = suffix.slice(2,4);
    next = { when: new Date(a.scheduledTime).toISOString(), label: `${hh}:${mm}`, alarmName: a.name };
  }
  return { autoEnabled: !!config.autoEnabled, next, alarms: auto.map(a => ({ name: a.name, when: new Date(a.scheduledTime).toISOString() })) };
}

async function testConnection() {
  return apiGet({ action: 'ping' });
}

async function scheduleAuto() {
  const times = [
    { hour: 15, minute: 0 },
    { hour: 18, minute: 0 },
    { hour: 20, minute: 30 }
  ];

  const alarms = await chrome.alarms.getAll();
  for (const alarm of alarms) {
    if (alarm.name && alarm.name.startsWith('verificador_auto_')) {
      await chrome.alarms.clear(alarm.name);
    }
  }

  const now = new Date();
  for (const t of times) {
    const next = new Date(now);
    next.setHours(t.hour, t.minute, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
    const name = `verificador_auto_${String(t.hour).padStart(2, '0')}${String(t.minute).padStart(2, '0')}`;
    await chrome.alarms.create(name, { when: next.getTime() });
  }
  return getAutoStatus();
}

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name === 'verificador_timeout') {
    const state = await getRunState();
    if (state.running && state.waitingContract) {
      await recordOutcome({
        type: 'error',
        code: 'TIMEOUT',
        message: 'Página demorou para carregar ou a informação não foi localizada dentro do tempo limite.'
      });
    }
    return;
  }

  if (alarm.name.startsWith('verificador_auto_')) {
    const config = await getConfig();
    if (!config.autoEnabled) return;

    try {
      const pending = await apiGet({ action: 'pending' });
      const queue = (pending.items || []).map(x => ({ ...x, selected: true }));
      if (queue.length) await startRun(queue);
    } catch (err) {
      const history = await getHistory();
      history.unshift({
        at: new Date().toISOString(),
        outcome: 'error',
        code: 'AUTO_FALHOU',
        message: err.message
      });
      history.splice(HISTORY_LIMIT);
      await chrome.storage.local.set({ verificadorHistory: history });
    }

    await scheduleAuto();
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.status !== 'complete') return;
  const state = await getRunState();
  if (!state.running || state.workerTabId !== tabId) return;
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'ANALYZE_BOLETO_NOW' });
  } catch (_) {
    // O content script pode ainda estar iniciando. Ele próprio também analisa no carregamento.
  }
});

chrome.tabs.onRemoved.addListener(async tabId => {
  const state = await getRunState();
  if (state.running && state.workerTabId === tabId) {
    await recordOutcome({
      type: 'error',
      code: 'ABA_FECHADA',
      message: 'A aba de verificação foi fechada antes da conclusão.'
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      switch (message.type) {
        case 'GET_CONFIG':
          sendResponse({ ok: true, config: await getConfig() });
          break;
        case 'SET_CONFIG': {
          const config = await setConfig(message.config || {});
          if (typeof message.config?.autoEnabled === 'boolean') {
            if (config.autoEnabled) await scheduleAuto();
            else {
              const alarms = await chrome.alarms.getAll();
              for (const alarm of alarms) {
                if (alarm.name.startsWith('verificador_auto_')) await chrome.alarms.clear(alarm.name);
              }
            }
          }
          sendResponse({ ok: true, config });
          break;
        }
        case 'TEST_CONNECTION':
          sendResponse({ ok: true, data: await testConnection() });
          break;
        case 'GET_AUTO_STATUS':
          sendResponse({ ok: true, ...await getAutoStatus() });
          break;
        case 'GET_PENDING':
          sendResponse({ ok: true, data: await refreshPending(message.sheet) });
          break;
        case 'GET_HISTORY':
          sendResponse({ ok: true, history: await getHistory() });
          break;
        case 'CLEAR_HISTORY':
          await chrome.storage.local.remove('verificadorHistory');
          sendResponse({ ok: true });
          break;
        case 'GET_RUN_STATE':
          sendResponse({ ok: true, state: await getRunState() });
          break;
        case 'START_RUN':
          await startRun(message.queue || []);
          sendResponse({ ok: true });
          break;
        case 'STOP_RUN':
          await stopRun();
          sendResponse({ ok: true });
          break;
        case 'BOLETO_RESULT':
          await handleResult(message.result || {});
          sendResponse({ ok: true });
          break;
        default:
          sendResponse({ ok: false, error: 'Mensagem não reconhecida.' });
      }
    } catch (err) {
      sendResponse({ ok: false, error: err?.message || String(err) });
    }
  })();
  return true;
});

(async () => {
  const config = await getConfig();
  if (config.autoEnabled) await scheduleAuto();
})();
