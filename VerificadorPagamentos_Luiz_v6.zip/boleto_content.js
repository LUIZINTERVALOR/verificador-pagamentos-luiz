(function () {
  const MAX_WAIT_MS = 20000;
  const POLL_MS = 700;
  let sent = false;

  function normalize(text) {
    return String(text || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
  }

  function getContract() {
    try {
      const url = new URL(location.href);
      return (url.searchParams.get('ban') || '').replace(/\D/g, '');
    } catch (_) {
      return '';
    }
  }

  function compactExcerpt(text) {
    return String(text || '').replace(/\s+/g, ' ').trim().slice(0, 420);
  }

  function hasAny(text, words) {
    return words.some(w => text.includes(normalize(w)));
  }

  function analyze() {
    if (sent) return null;
    const contract = getContract();
    const raw = document.body ? document.body.innerText || document.body.textContent || '' : '';
    const text = normalize(raw);
    if (!text || text.length < 20) return null;

    const paidPhrase = `nao ha entradas de parcelamento para a conta ${contract}`;
    const paidPhraseLoose = `nao ha entradas de parcelamento para a conta`;

    if (contract && text.includes(paidPhrase)) {
      return {
        status: 'VERIFICAR',
        code: 'SEM_ENTRADA_PARCELAMENTO',
        contract,
        message: `Não há entradas de parcelamento para a conta ${contract}.`,
        excerpt: compactExcerpt(raw),
        pageUrl: location.href
      };
    }

    const hasPendingTitle =
      text.includes('acordo encontrado') ||
      text.includes('dados da conta') ||
      text.includes('numero da conta');
    const hasPendingPurpose = text.includes('pagamento de entrada de parcelamento');
    const mentionsContract = !!contract && text.includes(contract);

    if (mentionsContract && (hasPendingPurpose || (hasPendingTitle && text.includes('numero do cliente')))) {
      return {
        status: 'PENDENTE',
        code: 'ACORDO_LOCALIZADO',
        contract,
        message: 'A ficha do acordo continua localizada no Boleto Avulso.',
        excerpt: compactExcerpt(raw),
        pageUrl: location.href
      };
    }

    const errorSignals = [
      'conta nao encontrada',
      'contrato nao encontrado',
      'nao foi possivel localizar',
      'boleto indisponivel',
      'erro interno',
      'pagina nao encontrada',
      'servico indisponivel',
      'sessao expirada'
    ];

    if (hasAny(text, errorSignals)) {
      return {
        status: 'ERRO',
        code: 'PAGINA_COM_ERRO',
        contract,
        message: 'A página exibiu uma mensagem de erro ou indisponibilidade.',
        excerpt: compactExcerpt(raw),
        pageUrl: location.href
      };
    }

    if (text.includes('boleto avulso') && text.includes(paidPhraseLoose) && contract) {
      return {
        status: 'ERRO',
        code: 'PAGAMENTO_SEM_CONTA',
        contract,
        message: 'A mensagem de pagamento foi encontrada, mas não foi possível confirmar a conta exata.',
        excerpt: compactExcerpt(raw),
        pageUrl: location.href
      };
    }

    return null;
  }

  async function trySend() {
    const result = analyze();
    if (!result) return false;
    sent = true;
    chrome.runtime.sendMessage({ type: 'BOLETO_RESULT', result }).catch(() => {});
    return true;
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'ANALYZE_BOLETO_NOW') trySend();
  });

  const started = Date.now();
  const timer = setInterval(async () => {
    const done = await trySend();
    if (done || Date.now() - started >= MAX_WAIT_MS) {
      clearInterval(timer);
      if (!done && !sent) {
        sent = true;
        chrome.runtime.sendMessage({
          type: 'BOLETO_RESULT',
          result: {
            status: 'ERRO',
            code: 'TIMEOUT_CONTEUDO',
            contract: getContract(),
            message: 'Extensão não conseguiu localizar a informação dentro do tempo limite.',
            excerpt: compactExcerpt(document.body?.innerText || ''),
            pageUrl: location.href
          }
        }).catch(() => {});
      }
    }
  }, POLL_MS);

  trySend();
})();
