const months = [
  'JANEIRO','FEVEREIRO','MARÇO','ABRIL','MAIO','JUNHO','JULHO','AGOSTO','SETEMBRO','OUTUBRO','NOVEMBRO','DEZEMBRO'
];

const $ = (id) => document.getElementById(id);
let queue = [];
let pollTimer = null;

function pad2(n) { return String(n).padStart(2, '0'); }
function currentSheetName() {
  const now = new Date();
  return `${months[now.getMonth()]} ${String(now.getFullYear()).slice(-2)}`;
}
function escapeHtml(text) {
  return String(text ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
}
function fmtDate(iso) {
  try { return new Date(iso).toLocaleString('pt-BR'); } catch { return iso || ''; }
}
function money(v) { if (v === '' || v == null) return ''; return String(v); }
function toast(message, kind='') {
  const el = $('toast');
  el.textContent = message;
  el.className = `toast ${kind}`;
  el.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.hidden = true; }, 4200);
}
function send(type, payload={}) { return chrome.runtime.sendMessage({ type, ...payload }); }

function closeHistoryModal() {
  const modal = $('historyModal');
  if (!modal) return;
  modal.hidden = true;
  modal.setAttribute('hidden', '');
}
function openHistoryModal() {
  const modal = $('historyModal');
  if (!modal) return;
  modal.removeAttribute('hidden');
  modal.hidden = false;
}
function closeDetailModal() {
  const modal = $('detailModal');
  if (!modal) return;
  modal.hidden = true;
  modal.setAttribute('hidden', '');
}
function openDetailModal() {
  const modal = $('detailModal');
  if (!modal) return;
  modal.removeAttribute('hidden');
  modal.hidden = false;
}

async function init() {
  const { config } = await send('GET_CONFIG');
  $('apiUrl').value = config.apiUrl || '';
  $('token').value = config.token || '';
  $('autoEnabled').checked = !!config.autoEnabled;

  const baseYear = new Date().getFullYear();
  months.forEach((m) => {
    const opt = document.createElement('option');
    opt.value = `${m} ${String(baseYear).slice(-2)}`;
    opt.textContent = opt.value;
    $('sheetSelect').appendChild(opt);
  });
  $('sheetSelect').value = currentSheetName();

  renderQueue();
  await refreshState();
  await refreshHistory();
  await refreshAutoStatus();
  await testConnection(false);
  pollTimer = setInterval(async () => {
    await refreshState();
    await refreshAutoStatus();
  }, 1000);
}

async function testConnection(showToast=true) {
  $('connectionBadge').textContent = 'TESTANDO...';
  $('connectionBadge').className = 'badge badge-off';
  const result = await send('TEST_CONNECTION');
  if (result.ok) {
    $('connectionBadge').textContent = 'CONECTADO';
    $('connectionBadge').className = 'badge badge-on';
    $('connectionBadge').title = 'Web App respondendo normalmente.';
    if (showToast) toast('✅ Conexão com o Web App funcionando.', 'good');
  } else {
    $('connectionBadge').textContent = 'NÃO CONECTADO';
    $('connectionBadge').className = 'badge badge-error';
    $('connectionBadge').title = result.error || 'Não foi possível conectar.';
    if (showToast) toast(`❌ Conexão falhou: ${result.error || 'erro desconhecido'}`, 'bad');
  }
  return result;
}

async function saveConfig(showConnection = false) {
  const result = await send('SET_CONFIG', {
    config: {
      apiUrl: $('apiUrl').value.trim(),
      token: $('token').value.trim(),
      autoEnabled: $('autoEnabled').checked
    }
  });
  if (!result.ok) throw new Error(result.error);
  toast('Configuração salva.', 'good');
  const conn = await testConnection(showConnection);
  await refreshAutoStatus();
  return conn;
}

async function importQueueFromClipboard() {
  try {
    if (!navigator.clipboard || !navigator.clipboard.readText) {
      throw new Error('A leitura da área de transferência não está disponível nesta versão da extensão.');
    }
    const raw = await navigator.clipboard.readText();
    if (!raw || !raw.trim()) {
      throw new Error('A área de transferência está vazia. Primeiro clique em ENVIAR PARA EXTENSÃO na Planilha Luiz.');
    }
    let payload;
    try { payload = JSON.parse(raw); }
    catch (_) { throw new Error('O conteúdo copiado não é a fila do Verificador. Volte à Planilha Luiz e clique em ENVIAR PARA EXTENSÃO novamente.'); }
    if (payload?.version !== 'VP_LUIZ_1' || !Array.isArray(payload.items)) {
      throw new Error('A fila copiada não é compatível com o Verificador de Pagamentos.');
    }
    const items = payload.items.filter(item => item && String(item.contract || '').replace(/\D/g, '').length > 0);
    queue = items.map(item => ({ ...item, contract: String(item.contract).replace(/\D/g, ''), status: 'PENDENTE', selected: true, source: 'PLANILHA_CLIPBOARD' }));
    $('sheetSelect').value = payload.sheet || currentSheetName();
    $('pendingCount').textContent = queue.length;
    $('queueSummary').textContent = `${queue.length} contrato(s) importado(s) da Planilha Luiz.`;
    $('runTitle').textContent = queue.length ? 'Fila importada da planilha' : 'Fila vazia';
    $('runMessage').textContent = queue.length ? 'Os contratos foram recebidos. Agora clique em VERIFICAR AGORA.' : 'Não havia contratos PENDENTES na fila.';
    renderQueue();
    $('btnStart').disabled = queue.length === 0;
    toast(`${queue.length} contrato(s) importado(s) com sucesso.`, 'good');
    await chrome.storage.local.set({ verificadorLastQueue: { ...payload, items: queue, importedAt: new Date().toISOString() } });
  } catch (err) { toast(err?.message || String(err), 'bad'); }
}

async function loadPending() {
  const sheet = $('sheetSelect').value;
  $('runTitle').textContent = `Carregando ${sheet}...`;
  $('runMessage').textContent = 'Buscando somente STATUS = PENDENTE.';
  const result = await send('GET_PENDING', { sheet });
  if (!result.ok) {
    toast(result.error || 'Erro ao buscar contratos.', 'bad');
    $('connectionBadge').textContent = 'ERRO';
    $('connectionBadge').className = 'badge badge-error';
    $('connectionBadge').title = result.error || 'Erro';
    return;
  }
  queue = (result.data.items || []).map(item => ({ ...item, selected: true }));
  $('pendingCount').textContent = queue.length;
  $('queueSummary').textContent = `${queue.length} contrato(s) PENDENTE(S) no mês selecionado.`;
  $('btnStart').disabled = queue.length === 0;
  renderQueue();
  $('runTitle').textContent = queue.length ? 'Fila carregada' : 'Nenhum PENDENTE encontrado';
  $('runMessage').textContent = queue.length ? 'Escolha os contratos e clique em VERIFICAR AGORA.' : 'Nada para verificar neste momento.';
  $('connectionBadge').textContent = 'CONECTADO';
  $('connectionBadge').className = 'badge badge-on';
  toast(`${queue.length} pendente(s) carregado(s).`, 'good');
}

function renderQueue() {
  const box = $('queue');
  box.innerHTML = '';
  if (!queue.length) { box.innerHTML = '<div class="muted" style="padding:12px">Nenhum contrato carregado.</div>'; return; }
  queue.forEach((item, idx) => {
    const row = document.createElement('label');
    row.className = 'queue-item';
    row.innerHTML = `<input type="checkbox" data-idx="${idx}" ${item.selected ? 'checked' : ''}><div class="queue-contract">${escapeHtml(item.contract)}</div><div class="queue-name" title="${escapeHtml(item.name)}">${escapeHtml(item.name || 'Cliente sem nome')}</div><div class="queue-value">${escapeHtml(money(item.value))}</div>`;
    row.querySelector('input').addEventListener('change', (e) => { queue[idx].selected = e.target.checked; updateStartButton(); });
    box.appendChild(row);
  });
  updateStartButton();
}
function selectedQueue() { return queue.filter(item => item.selected).map(item => ({ ...item })); }
function updateStartButton() {
  send('GET_RUN_STATE').then(result => {
    const running = !!result.state?.running;
    $('btnStart').disabled = running || selectedQueue().length === 0;
    $('btnStop').disabled = !running;
  }).catch(() => {});
}
async function startRun() {
  const selected = selectedQueue();
  if (!selected.length) { toast('Selecione pelo menos um contrato.', 'bad'); return; }
  const result = await send('START_RUN', { queue: selected });
  if (!result.ok) return toast(result.error || 'Não foi possível iniciar.', 'bad');
  toast(`Verificação iniciada: ${selected.length} contrato(s).`, 'good');
  await refreshState();
}
async function stopRun() {
  const result = await send('STOP_RUN');
  if (!result.ok) toast(result.error || 'Não foi possível parar.', 'bad');
  else toast('Verificação interrompida.', 'good');
  await refreshState();
}

async function refreshState() {
  const result = await send('GET_RUN_STATE');
  if (!result.ok) return;
  const s = result.state;
  const total = s.queue?.length || 0;
  const done = s.verified || 0;
  const percent = total ? Math.min(100, Math.round(done / total * 100)) : 0;
  $('statPending').textContent = s.pending || 0;
  $('statChanged').textContent = s.changed || 0;
  $('statErrors').textContent = s.errors || 0;
  $('statVerified').textContent = done;
  $('runPercent').textContent = `${percent}%`;
  $('progressBar').style.width = `${percent}%`;
  const running = !!s.running;
  $('btnStart').disabled = running || selectedQueue().length === 0;
  $('btnStop').disabled = !running;
  $('currentCard').hidden = !running || !s.current;
  if (running && s.current) {
    $('runTitle').textContent = `VERIFICANDO ${Math.min(done + 1, total)} / ${total}`;
    $('runMessage').textContent = 'Acessando o Boleto Avulso e conferindo a conta...';
    $('currentContract').textContent = s.current.contract || '—';
    $('currentName').textContent = s.current.name || 'Cliente sem nome';
    $('currentMeta').textContent = `Venc.: ${s.current.dueDate || '—'}  •  Valor: ${s.current.value || '—'}`;
    $('currentStatus').textContent = 'CONSULTANDO';
    $('currentStatus').style.background = '#e8f1ff';
    $('currentStatus').style.color = '#0b5dbd';
  } else if (!running && s.lastResult?.type === 'done') {
    $('runTitle').textContent = 'Fila concluída';
    $('runMessage').textContent = `${done} contrato(s) verificado(s).`;
    $('currentCard').hidden = true;
    if (total) $('progressBar').style.width = '100%';
    $('runPercent').textContent = total ? '100%' : '0%';
    await refreshHistory();
  }
}

async function refreshHistory() {
  const result = await send('GET_HISTORY');
  if (!result.ok) return [];
  const history = result.history || [];
  $('lastCheck').textContent = history.length ? `${fmtDate(history[0].at)} • ${history[0].contract || ''}` : 'Ainda não há histórico.';
  const preview = $('historyPreview');
  preview.innerHTML = '';
  history.slice(0, 4).forEach(item => {
    const dotClass = item.outcome === 'changed' ? 'dot-green' : item.outcome === 'pending' ? 'dot-yellow' : 'dot-red';
    const line = document.createElement('div');
    line.className = 'history-line';
    line.innerHTML = `<span class="dot ${dotClass}"></span><strong>${escapeHtml(item.contract || '—')}</strong><span>${escapeHtml(item.name || '')}</span>`;
    preview.appendChild(line);
  });
  if (!history.length) preview.innerHTML = '<div class="muted">O histórico aparecerá aqui após a primeira rodada.</div>';
  return history;
}

function outcomeLabel(outcome) {
  return outcome === 'changed' ? 'VERIFICAR' : outcome === 'pending' ? 'PENDENTE' : 'ERRO';
}
function outcomeClass(outcome) {
  return outcome === 'changed' ? 'pill-green' : outcome === 'pending' ? 'pill-yellow' : 'pill-red';
}
async function showOutcomeDetails(kind) {
  const history = await refreshHistory();
  const target = kind === 'pending' ? 'pending' : kind === 'changed' ? 'changed' : kind === 'error' ? 'error' : null;
  const filtered = target ? history.filter(x => x.outcome === target) : history;
  const title = target === 'changed' ? 'POSSÍVEIS PAGAMENTOS — VERIFICAR' : target === 'pending' ? 'ACORDOS AINDA PENDENTES' : target === 'error' ? 'ERROS DA VERIFICAÇÃO' : 'TODOS OS VERIFICADOS';
  $('detailTitle').textContent = title;
  $('detailSummary').textContent = filtered.length
    ? `${filtered.length} registro(s). Cada item mostra o cliente e exatamente a mensagem que a verificação registrou.`
    : 'Nenhum registro deste tipo foi encontrado no histórico.';
  const list = $('detailList');
  list.innerHTML = '';
  filtered.forEach(item => {
    const row = document.createElement('div');
    row.className = 'detail-item';
    row.innerHTML = `
      <div class="top"><span><strong>${escapeHtml(item.contract || '—')}</strong></span><span class="${outcomeClass(item.outcome)}">${escapeHtml(outcomeLabel(item.outcome))}</span></div>
      <div class="client">${escapeHtml(item.name || 'Cliente sem nome')}</div>
      <div class="meta">${escapeHtml(item.sheet || '')} • linha ${escapeHtml(item.rowNumber || '—')} • ${escapeHtml(fmtDate(item.at))} • ${escapeHtml(item.value || '')} • venc. ${escapeHtml(item.dueDate || '')}</div>
      <div class="message">${escapeHtml(item.message || 'Sem mensagem registrada.')}</div>
      ${item.excerpt ? `<div class="excerpt"><strong>Texto capturado:</strong> ${escapeHtml(item.excerpt)}</div>` : ''}
    `;
    list.appendChild(row);
  });
  openDetailModal();
}

async function showHistory() {
  const result = await send('GET_HISTORY');
  if (!result.ok) return;
  const list = $('historyList');
  list.innerHTML = '';
  for (const item of (result.history || [])) {
    const outcome = outcomeLabel(item.outcome);
    const row = document.createElement('div');
    row.className = 'history-row';
    row.innerHTML = `
      <div class="history-row-top"><span class="code">${escapeHtml(item.contract || '—')} • ${escapeHtml(outcome)}</span><span>${escapeHtml(fmtDate(item.at))}</span></div>
      <div style="font-size:9px;font-weight:800;margin-top:3px">${escapeHtml(item.name || '')}</div>
      <div class="msg">${escapeHtml(item.message || '')}</div>
    `;
    list.appendChild(row);
  }
  openHistoryModal();
}

async function refreshAutoStatus() {
  const result = await send('GET_AUTO_STATUS');
  if (!result.ok) return;
  const el = $('autoStatus');
  if (!result.autoEnabled) {
    el.textContent = '⏸ Automação de horários DESATIVADA. Para ativar: marque a caixa acima e salve.';
    el.style.color = '#5c6b7c';
    el.style.background = '#f3f6f9';
    return;
  }
  if (result.next) {
    el.textContent = `🟢 Automação ATIVA • próxima verificação: ${result.next.label} (${fmtDate(result.next.when)})`;
  } else {
    el.textContent = '🟢 Automação ATIVA • horários 15:00 • 18:00 • 20:30 registrados.';
  }
  el.style.color = '#116e3a';
  el.style.background = '#e6f8ed';
}

$('btnImportClipboard').addEventListener('click', importQueueFromClipboard);
$('btnLoad').addEventListener('click', loadPending);
$('btnStart').addEventListener('click', startRun);
$('btnStop').addEventListener('click', stopRun);
$('btnRefresh').addEventListener('click', async () => { await loadPending(); await refreshHistory(); await refreshState(); await refreshAutoStatus(); await testConnection(true); });
$('btnSelectAll').addEventListener('click', () => { queue.forEach(x => x.selected = true); renderQueue(); });
$('btnClearAll').addEventListener('click', () => { queue.forEach(x => x.selected = false); renderQueue(); });
$('btnTest').addEventListener('click', async () => { try { await saveConfig(true); } catch (e) { toast(e.message, 'bad'); } });
$('autoEnabled').addEventListener('change', async () => { try { await saveConfig(true); } catch (e) { toast(e.message, 'bad'); } });
$('apiUrl').addEventListener('change', async () => { try { await saveConfig(false); } catch (e) { toast(e.message, 'bad'); } });
$('token').addEventListener('change', async () => { try { await saveConfig(false); } catch (e) { toast(e.message, 'bad'); } });
$('btnHistory').addEventListener('click', showHistory);
$('btnCloseHistory').addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); closeHistoryModal(); });
$('historyModal').addEventListener('click', (event) => { if (event.target === $('historyModal')) closeHistoryModal(); });
$('btnClearHistory').addEventListener('click', async (event) => {
  event.preventDefault(); event.stopPropagation();
  const result = await send('CLEAR_HISTORY');
  if (!result.ok) { toast(result.error || 'Não foi possível limpar o histórico.', 'bad'); return; }
  await refreshHistory();
  await showHistory();
  toast('Histórico limpo.', 'good');
});
$('btnCloseDetail').addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); closeDetailModal(); });
$('detailModal').addEventListener('click', (event) => { if (event.target === $('detailModal')) closeDetailModal(); });
$('cardPending').addEventListener('click', () => showOutcomeDetails('pending'));
$('cardChanged').addEventListener('click', () => showOutcomeDetails('changed'));
$('cardErrors').addEventListener('click', () => showOutcomeDetails('error'));
$('cardVerified').addEventListener('click', () => showOutcomeDetails('all'));
['cardPending','cardChanged','cardErrors','cardVerified'].forEach(id => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $(id).click(); } }));
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') { closeHistoryModal(); closeDetailModal(); } });

init().catch(err => toast(err?.message || String(err), 'bad'));
