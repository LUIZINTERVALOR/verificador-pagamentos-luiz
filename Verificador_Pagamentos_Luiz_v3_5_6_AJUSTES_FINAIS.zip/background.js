const DEFAULT_DELAY_MS = 1200;
const DEFAULT_TIMEOUT_MS = 20000;
const BOLETO_BASE = 'http://totem/Totem/ExibeBoleto?idFinalidade=PAR&usuario=&ban=';
const STORAGE_KEY = 'verificador_pagamentos_luiz_v2';
const ALARM_NAME = 'verificador_pagamentos_auto_check';
const DEFAULT_INTERVAL_MIN = 30;
const DEFAULT_BRIDGE_TOKEN = '59513c62d23cc730c1eef6cb76f79e5c3848baae084c381cea6f312260db3fa6';
const DEFAULT_BRIDGE_URL = 'https://script.google.com/macros/s/AKfycbw30Lj7QzBFu0u5qNRbpHTkz62ZfLvfwwTJPr5XjkHbKZXLSRR6jU_cJAhyfiuj57tp0g/exec';
const EXT_VERSION = '3.5.5';

let currentTimer = null;
let timeoutTimer = null;
let scanRetryTimer = null;

function defaultState() {
  return {
    version: 3,
    extensionVersion: EXT_VERSION,
    running: false,
    stopped: false,
    index: 0,
    total: 0,
    processed: 0,
    contracts: [],
    results: [],
    current: null,
    currentTabId: null,
    lastAgreementTabId: null,
    delayMs: DEFAULT_DELAY_MS,
    timeoutMs: DEFAULT_TIMEOUT_MS,
    startedAt: null,
    finishedAt: null,
    automationEnabled: false,
    intervalMin: DEFAULT_INTERVAL_MIN,
    nextRunAt: null,
    lastRunStart: null,
    lastRunEnd: null,
    lastRunSummary: null,
    history: [],
    dailySummary: null,
    dailySummaryNotified: null,
    bridgeUrl: DEFAULT_BRIDGE_URL,
    bridgeToken: DEFAULT_BRIDGE_TOKEN,
    bridgeConnected: false,
    queueItems: [],
    requestId: 0,
    lastHandledRequestId: null
  };
}

async function getState() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  const base = defaultState();
  const merged = { ...base, ...(data[STORAGE_KEY] || {}) };
  if (!String(merged.bridgeUrl || '').trim()) merged.bridgeUrl = DEFAULT_BRIDGE_URL;
  if (!String(merged.bridgeToken || '').trim()) merged.bridgeToken = DEFAULT_BRIDGE_TOKEN;
  merged.extensionVersion = EXT_VERSION;
  return merged;
}

async function setState(state) { await chrome.storage.local.set({ [STORAGE_KEY]: state }); }
function onlyDigits(value) { return String(value || '').replace(/\D/g, ''); }
function boletoUrl(contract) { return BOLETO_BASE + encodeURIComponent(contract); }
function normalizeStatus(status) {
  const s = String(status || '').toUpperCase();
  if (s === 'ACORDO ENCONTRADO' || s === 'PENDENTE') return 'PENDENTE';
  if (s === 'VERIFICAR') return 'VERIFICAR';
  return 'ERRO';
}

async function ensureTab() {
  const state = await getState();
  if (state.currentTabId) {
    try {
      const tab = await chrome.tabs.get(state.currentTabId);
      if (tab && tab.id) return tab.id;
    } catch (_) {}
  }
  const tab = await chrome.tabs.create({ url: 'about:blank', active: false });
  state.currentTabId = tab.id;
  await setState(state);
  return tab.id;
}

async function bridgeGet(action, extra = {}) {
  const state = await getState();
  if (!state.bridgeUrl) throw new Error('A ponte da planilha ainda não foi configurada.');
  const url = new URL(state.bridgeUrl);
  url.searchParams.set('action', action);
  url.searchParams.set('token', state.bridgeToken || DEFAULT_BRIDGE_TOKEN);
  Object.entries(extra).forEach(([k, v]) => url.searchParams.set(k, v == null ? '' : String(v)));
  const response = await fetch(url.toString(), { method: 'GET', cache: 'no-store' });
  if (!response.ok) throw new Error('A ponte respondeu HTTP ' + response.status + '.');
  const text = await response.text();
  let data;
  try { data = JSON.parse(text); } catch (_) { throw new Error('A ponte não retornou JSON válido.'); }
  if (data && data.ok === false) throw new Error(data.error || data.mensagem || 'Erro na ponte.');
  return data;
}

async function bridgePending() {
  const data = await bridgeGet('pending');
  const state = await getState();
  state.bridgeConnected = true;
  await setState(state);
  return data && Array.isArray(data.items) ? data.items : [];
}

async function bridgeMarkVerificar(item, contract) {
  if (!item || !item.rowNumber || !item.sheet) return { skipped: true };
  return bridgeGet('update', { sheet:item.sheet, row:item.rowNumber, contract, status:'VERIFICAR' });
}

async function notify(title, message, idPrefix = 'verificador', stableKey = '') {
  try {
    const notificationId = stableKey ? (idPrefix + '-' + String(stableKey).replace(/[^0-9A-Za-z_-]/g,'')) : (idPrefix + '-' + Date.now());
    if (stableKey) { try { await chrome.notifications.clear(notificationId); } catch (_) {} }
    await chrome.notifications.create(notificationId, { type:'basic', iconUrl:'icon.png', title, message });
  } catch (_) {}
}

async function scheduleAlarm() {
  const state = await getState();
  if (!state.automationEnabled) {
    await chrome.alarms.clear(ALARM_NAME);
    state.nextRunAt = null;
    await setState(state);
    return;
  }
  const period = Math.max(15, Number(state.intervalMin) || DEFAULT_INTERVAL_MIN);
  await chrome.alarms.clear(ALARM_NAME);
  await chrome.alarms.create(ALARM_NAME, { delayInMinutes: period, periodInMinutes: period });
  state.nextRunAt = new Date(Date.now() + period * 60000).toISOString();
  await setState(state);
}

async function fetchCurrentQueue() {
  try {
    const items = await bridgePending();
    return items.map(x => ({
      contract: onlyDigits(x.contract), name:x.name||'', dueDate:x.dueDate||'', value:x.value||'', status:'PENDENTE', sheet:x.sheet||'', rowNumber:Number(x.rowNumber||0)
    })).filter(x=>x.contract);
  } catch (e) {
    const state = await getState();
    state.bridgeConnected = false;
    await setState(state);
    throw e;
  }
}

async function startQueue(items, delayMs, timeoutMs) {
  if (!items.length) {
    const now = new Date().toISOString();
    const state = await getState();
    state.running=false; state.processed=0; state.total=0; state.contracts=[]; state.results=[]; state.queueItems=[];
    state.lastRunSummary={ total:0, verificar:0, pendente:0, erro:0, start:now, end:now, message:'Nenhum contrato pendente na planilha.' };
    state.lastRunEnd=now;
    state.finishedAt=now;
    state.nextRunAt=state.automationEnabled ? new Date(Date.now() + (Number(state.intervalMin)||DEFAULT_INTERVAL_MIN)*60000).toISOString() : null;
    await setState(state);
    await maybeDailySummary(state.lastRunSummary);
    return;
  }

  if (currentTimer) clearTimeout(currentTimer);
  if (timeoutTimer) clearTimeout(timeoutTimer);
  if (scanRetryTimer) clearTimeout(scanRetryTimer);

  const old = await getState();
  // A V3.0 usava uma única aba durante a rodada. Mantemos esse comportamento
  // para evitar "Navigation rejected" e impedir acúmulo de abas do Totem.
  const tabId = await ensureTab();
  const contracts = items.map(x=>onlyDigits(x.contract)).filter(Boolean);
  const itemByContract = Object.fromEntries(items.map(x=>[onlyDigits(x.contract),x]));
  const now = new Date().toISOString();
  const state = {
    ...old,
    requestId: Number(old.requestId || 0),
    lastHandledRequestId: null,
    running:true,
    stopped:false,
    index:0,
    total:contracts.length,
    processed:0,
    contracts,
    itemMeta:itemByContract,
    results:items.map(x=>({contract:onlyDigits(x.contract),status:'PENDENTE',name:x.name||'',dueDate:x.dueDate||'',value:x.value||'',sheet:x.sheet||'',rowNumber:Number(x.rowNumber||0),aguardando:true})),
    current:contracts[0],
    currentTabId:tabId,
    delayMs:Number(delayMs)||DEFAULT_DELAY_MS,
    timeoutMs:Number(timeoutMs)||DEFAULT_TIMEOUT_MS,
    startedAt:now,
    lastRunStart:now,
    finishedAt:null,
    lastRunEnd:null,
    lastRunSummary:null,
    queueItems:items.map(x=>({...x,contract:onlyDigits(x.contract),status:'PENDENTE'}))
  };
  await setState(state);
  await openCurrent();
}

async function runCycle(source='manual') {
  const state=await getState();
  if(state.running) return {ok:false,error:'Já existe uma verificação em andamento.'};
  let items;
  try { items=await fetchCurrentQueue(); }
  catch(e){ await notify('🔴 Verificador de Pagamentos — erro na ponte',e.message||String(e),'bridge'); return {ok:false,error:e.message||String(e)}; }
  await startQueue(items,state.delayMs,state.timeoutMs);
  return {ok:true,total:items.length,source};
}

async function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

async function sendScanWithRetry(tabId, requestId, expectedContract, maxAttempts=8) {
  let attempt=0;
  const go=async()=>{
    const state=await getState();
    if(!state.running || state.currentTabId!==tabId || Number(state.requestId||0)!==Number(requestId||0) || state.current!==expectedContract) return false;
    attempt++;
    try {
      await chrome.tabs.sendMessage(tabId,{type:'SCAN_TOTEM',requestId,expectedContract});
      return true;
    } catch (_) {
      if(attempt>=maxAttempts) return false;
      await delay(450);
      return go();
    }
  };
  return go();
}

async function navigateSameTabWithRetry(tabId, url, attempts=4) {
  let lastError = null;
  for (let i=0; i<attempts; i++) {
    try {
      await chrome.tabs.update(tabId, { url, active: false });
      return true;
    } catch (e) {
      lastError = e;
      await delay(350);
    }
  }
  throw lastError || new Error('Navigation rejected');
}

async function openCurrent() {
  const state=await getState();
  if(!state.running || state.index>=state.total){ await finishQueue(); return; }
  const contract=state.contracts[state.index];
  const requestId=Number(state.requestId||0)+1;
  state.requestId=requestId;
  state.lastHandledRequestId=null;
  state.current=contract;

  let tabId=state.currentTabId;
  try {
    // Reusa a mesma aba da V3.0. Só cria outra se a anterior realmente não existir.
    try { if(tabId) await chrome.tabs.get(tabId); else throw new Error('ABA_AUSENTE'); }
    catch(_) { tabId=await ensureTab(); }
    state.currentTabId=tabId;
    await setState(state);

    if(timeoutTimer) clearTimeout(timeoutTimer);
    timeoutTimer=setTimeout(async()=>{
      const fresh=await getState();
      if(!fresh.running || fresh.index>=fresh.total || fresh.current!==contract || Number(fresh.requestId||0)!==requestId) return;
      await addResult({requestId,expectedContract:contract,contract,status:'ERRO',mensagem:'Tempo excedido esperando a página responder.'});
    }, Number(state.timeoutMs)||DEFAULT_TIMEOUT_MS);

    await navigateSameTabWithRetry(tabId, boletoUrl(contract), 4);
    await sendScanWithRetry(tabId,requestId,contract,18);
  } catch(e) {
    await addResult({requestId,expectedContract:contract,contract,status:'ERRO',mensagem:'Não foi possível abrir a página do Boleto Avulso: '+(e.message||e)});
  }
}

async function addResult(raw) {
  if(timeoutTimer) clearTimeout(timeoutTimer);
  timeoutTimer=null;
  const state=await getState();
  if(!state.running) return;
  const requestId=Number(raw.requestId||0);
  const expected=onlyDigits(state.contracts[state.index]||state.current||'');
  if(!requestId || requestId!==Number(state.requestId||0)) return;
  if(raw.senderTabId && Number(raw.senderTabId)!==Number(state.currentTabId||0)) return;
  if(state.lastHandledRequestId===requestId) return;
  const expectedFromMessage=onlyDigits(raw.expectedContract||'');
  if(expectedFromMessage && expectedFromMessage!==expected) return;
  state.lastHandledRequestId=requestId;
  const result={...raw,status:normalizeStatus(raw.status),contract:expected||onlyDigits(raw.contract||''),consultadoEm:new Date().toISOString()};
  const pageAccount=onlyDigits(result.conta||'');
  if(pageAccount && expected && pageAccount!==expected){ result.status='ERRO'; result.mensagem='A página retornou outro número de conta: '+pageAccount+'. Consulta bloqueada por segurança.'; }
  const item=(state.itemMeta||{})[expected]||{};
  result.nomePlanilha=item.name||''; result.rowNumber=item.rowNumber||0; result.sheet=item.sheet||'';
  result.aguardando=false;
  state.processed=Number(state.processed||0)+1;
  const existingIndex=state.results.findIndex(r=>onlyDigits(r.contract)===expected);
  if(existingIndex>=0) state.results[existingIndex]=result; else state.results.push(result);

  if(result.status==='VERIFICAR'){
    try{
      await bridgeMarkVerificar(item,expected);
      result.ponte='ATUALIZADO';
      state.queueItems=(state.queueItems||[]).filter(x=>onlyDigits(x.contract)!==expected);
    }catch(e){
      result.ponte='ERRO';
      result.mensagem=(result.mensagem?result.mensagem+' ':'')+'A planilha não pôde ser atualizada: '+e.message;
      result.status='ERRO';
    }
    const updatedIndex=state.results.findIndex(r=>onlyDigits(r.contract)===expected);
    if(updatedIndex>=0) state.results[updatedIndex]=result;
  }

  if(result.status==='VERIFICAR') await notify('🟢 POSSÍVEL PAGAMENTO','Contrato '+expected+' precisa de conferência na planilha.','verificar',expected);
  state.index+=1;
  state.current=state.contracts[state.index]||null;
  await setState(state);
  if(state.index>=state.total){ await finishQueue(); return; }
  currentTimer=setTimeout(openCurrent,state.delayMs);
}

function makeSummary(state){
  const results=state.results||[];
  return { total:state.total||0, verificar:results.filter(r=>r.status==='VERIFICAR').length, pendente:results.filter(r=>r.status==='PENDENTE').length, erro:results.filter(r=>r.status==='ERRO').length, start:state.lastRunStart||state.startedAt||null, end:state.finishedAt||new Date().toISOString(), verificarContracts:results.filter(r=>r.status==='VERIFICAR').map(r=>r.contract), erroContracts:results.filter(r=>r.status==='ERRO').map(r=>r.contract) };
}

async function maybeDailySummary(summary){
  const state=await getState();
  const today=new Date().toLocaleDateString('sv-SE');
  state.dailySummary={...summary,date:today};
  if(state.dailySummaryNotified!==today){ state.dailySummaryNotified=today; await setState(state); await notify('📊 Seu resumo do dia está pronto',`${summary.total} verificados • 🟢 ${summary.verificar} para verificar • 🔴 ${summary.erro} erros.`,'resumo'); }
  else await setState(state);
}

async function finishQueue(){
  if(currentTimer) clearTimeout(currentTimer); if(timeoutTimer) clearTimeout(timeoutTimer); if(scanRetryTimer) clearTimeout(scanRetryTimer);
  currentTimer=null; timeoutTimer=null; scanRetryTimer=null;
  const state=await getState();
  state.running=false; state.current=null; state.finishedAt=new Date().toISOString(); state.lastRunEnd=state.finishedAt;
  const summary=makeSummary(state); state.lastRunSummary=summary; state.history=[summary,...(state.history||[])].slice(0,30);
  state.nextRunAt=state.automationEnabled ? new Date(Date.now()+(Number(state.intervalMin)||DEFAULT_INTERVAL_MIN)*60000).toISOString() : null;
  await setState(state); await maybeDailySummary(summary); if(state.automationEnabled) await scheduleAlarm();
}

async function handleTotemReady(tabId){
  const state=await getState();
  if(!state.running || tabId!==state.currentTabId || !state.current) return;
  await sendScanWithRetry(tabId,Number(state.requestId||0),state.current,18);
}

chrome.tabs.onUpdated.addListener(async(tabId,changeInfo)=>{
  if(changeInfo.status!=='complete') return;
  const state=await getState();
  if(!state.running || Number(tabId)!==Number(state.currentTabId||0) || !state.current) return;
  const requestId=Number(state.requestId||0);
  const expected=state.current;
  await delay(250);
  const fresh=await getState();
  if(!fresh.running || Number(fresh.currentTabId||0)!==Number(tabId) || fresh.current!==expected || Number(fresh.requestId||0)!==requestId) return;
  await sendScanWithRetry(tabId,requestId,expected,18);
});

chrome.runtime.onMessage.addListener((msg,sender)=>{
  if(msg?.type==='TOTEM_RESULT' && msg.result) addResult({...msg.result, senderTabId: sender?.tab?.id || null});
  if(msg?.type==='TOTEM_READY' && sender?.tab?.id) handleTotemReady(sender.tab.id);
});

chrome.notifications?.onClicked?.addListener(async(notificationId)=>{
  try{ const state=await getState(); const targetId=state.lastAgreementTabId||state.currentTabId; if(targetId){ await chrome.tabs.update(targetId,{active:true}); const tab=await chrome.tabs.get(targetId); if(tab?.windowId) await chrome.windows.update(tab.windowId,{focused:true}); }}catch(_){ }
  try{ chrome.notifications.clear(notificationId); }catch(_){ }
});

chrome.alarms.onAlarm.addListener(async(alarm)=>{
  if(alarm.name!==ALARM_NAME) return;
  const state=await getState();
  if(!state.automationEnabled || state.running) return;
  await runCycle('automatico');
  const fresh=await getState();
  fresh.nextRunAt=new Date(Date.now()+(Number(fresh.intervalMin)||DEFAULT_INTERVAL_MIN)*60000).toISOString();
  await setState(fresh);
});

async function recoverAfterUpgradeOrStartup(reason){
  const stored=await chrome.storage.local.get(STORAGE_KEY);
  const raw=stored[STORAGE_KEY] || {};
  const state=await getState();
  if(reason==='update' && raw.extensionVersion && raw.extensionVersion!==EXT_VERSION){
    state.running=false;
    state.stopped=true;
    state.current=null;
    state.currentTabId=null;
    state.processed=0;
    state.index=0;
    state.total=0;
    state.contracts=[];
    state.queueItems=[];
    state.nextRunAt=null;
    state.extensionVersion=EXT_VERSION;
    await setState(state);
  } else if(state.running && state.currentTabId){
    try{ await chrome.tabs.get(state.currentTabId); }
    catch(_){
      state.running=false; state.stopped=true; state.current=null; state.currentTabId=null; state.index=0; state.processed=0; state.total=0; state.contracts=[]; state.queueItems=[];
      await setState(state);
    }
  }
  const fresh=await getState();
  if(fresh.automationEnabled) await scheduleAlarm();
}

chrome.runtime.onInstalled.addListener(async(info)=>{ await recoverAfterUpgradeOrStartup(info?.reason||'install'); });
chrome.runtime.onStartup.addListener(async()=>{ await recoverAfterUpgradeOrStartup('startup'); });

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  (async()=>{
    try{
      if(!msg) return;
      if(msg.type==='START_QUEUE' || msg.type==='RUN_NOW') sendResponse(await runCycle('manual'));
      else if(msg.type==='STOP_QUEUE'){
        const state=await getState();
        const tabIdToClose=state.currentTabId;
        state.running=false; state.stopped=true; state.current=null; state.currentTabId=null;
        if(currentTimer) clearTimeout(currentTimer); if(timeoutTimer) clearTimeout(timeoutTimer); if(scanRetryTimer) clearTimeout(scanRetryTimer);
        currentTimer=null; timeoutTimer=null; scanRetryTimer=null; await setState(state);
        if(tabIdToClose){ try{ await chrome.tabs.remove(tabIdToClose); }catch(_){} }
        sendResponse({ok:true});
      }else if(msg.type==='GET_STATE') sendResponse({ok:true,state:await getState()});
      else if(msg.type==='SAVE_SETTINGS'){
        const state=await getState(); state.bridgeUrl=String(msg.bridgeUrl||'').trim(); state.bridgeToken=String(msg.bridgeToken||DEFAULT_BRIDGE_TOKEN).trim(); state.intervalMin=Math.max(15,Number(msg.intervalMin)||DEFAULT_INTERVAL_MIN); state.automationEnabled=!!msg.automationEnabled;
        if(state.automationEnabled && !state.bridgeUrl) throw new Error('Para ativar a verificação automática, informe a URL /exec da ponte da planilha.');
        state.delayMs=Number(msg.delayMs)||DEFAULT_DELAY_MS; state.timeoutMs=Number(msg.timeoutMs)||DEFAULT_TIMEOUT_MS; await setState(state); await scheduleAlarm(); sendResponse({ok:true,state:await getState()});
      }else if(msg.type==='SAVE_TIMINGS'){
        const state=await getState();
        const intervalMin=Number(msg.intervalMin);
        const timeoutMs=Number(msg.timeoutMs);
        if(!Number.isFinite(intervalMin) || intervalMin<15) throw new Error('Intervalo inválido. O mínimo é 15 minutos.');
        if(!Number.isFinite(timeoutMs) || timeoutMs<1000) throw new Error('Tempo máximo inválido.');
        state.intervalMin=intervalMin;
        state.timeoutMs=timeoutMs;
        await setState(state);
        await scheduleAlarm();
        sendResponse({ok:true,state:await getState()});
      }else if(msg.type==='TEST_BRIDGE'){
        try{
          const data=await bridgeGet('ping');
          const items=await bridgePending();
          const state=await getState();
          state.bridgeConnected=true;
          state.queueItems=items.map(x=>({...x,contract:onlyDigits(x.contract),status:'PENDENTE',rowNumber:Number(x.rowNumber||0)})).filter(x=>x.contract);
          state.contracts=state.queueItems.map(x=>x.contract); state.total=state.contracts.length; state.processed=0; state.index=0; state.current=null; state.finishedAt=null;
          state.results=state.queueItems.map(x=>({contract:x.contract,status:'PENDENTE',name:x.name||'',dueDate:x.dueDate||'',value:x.value||'',sheet:x.sheet||'',rowNumber:x.rowNumber||0,aguardando:true}));
          await setState(state); sendResponse({ok:true,data,total:items.length});
        }catch(e){ const state=await getState(); state.bridgeConnected=false; await setState(state); sendResponse({ok:false,error:e.message||String(e)}); }
      }else if(msg.type==='IMPORT_BRIDGE_NOW'){
        const items=await bridgePending(); const state=await getState();
        state.bridgeConnected=true; state.queueItems=items.map(x=>({...x,contract:onlyDigits(x.contract),status:'PENDENTE',rowNumber:Number(x.rowNumber||0)})).filter(x=>x.contract);
        state.contracts=state.queueItems.map(x=>x.contract); state.total=state.contracts.length; state.processed=0; state.index=0; state.running=false; state.stopped=false; state.current=null; state.finishedAt=null; state.lastRunSummary=null;
        state.results=state.queueItems.map(x=>({contract:x.contract,status:'PENDENTE',name:x.name||'',dueDate:x.dueDate||'',value:x.value||'',sheet:x.sheet||'',rowNumber:x.rowNumber||0,aguardando:true}));
        await setState(state); sendResponse({ok:true,total:items.length,items});
      }else if(msg.type==='RESET'){ await chrome.alarms.clear(ALARM_NAME); await setState(defaultState()); sendResponse({ok:true}); }
      else if(msg.type==='CLEAR_DAILY_NOTICE'){ const state=await getState(); state.dailySummaryNotified=new Date().toLocaleDateString('sv-SE'); await setState(state); sendResponse({ok:true}); }
    }catch(e){ sendResponse({ok:false,error:e.message||String(e)}); }
  })();
  return true;
});
